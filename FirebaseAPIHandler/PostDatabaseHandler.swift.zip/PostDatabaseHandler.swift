//
//  PostDatabaseHandler.swift
//  SocialNetworking
//
//  Created by Andrew Bailey on 11/29/18.
//  Copyright © 2018 Andrew Bailey. All rights reserved.
//

// Users Regarding Posts (Database)
// USERS/USERID/information["POSTS"] -> Array<String>

import Foundation
import FirebaseAuth

extension FirebaseAPIHandler {
    
    func uploadPost(post: Post, completion: @escaping (Bool) -> ())
    {
        guard let postID = databaseReference.child(FirebaseAPIHandler.databaseFolders.postsFolder).childByAutoId().key else {
            return
        }
        var successes = [false, false, false]
        
        let postUploadingGroup = DispatchGroup()
        postUploadingGroup.enter()
        FirebaseAPIHandler.shared.uploadImage(folder: FirebaseAPIHandler.storageFolders.postImagesFolder, id: postID, image: post.postImage)
        {
            (success) in
            successes[0] = success
            postUploadingGroup.leave()
        }
        
        postUploadingGroup.enter()
        databaseReference.child(FirebaseAPIHandler.databaseFolders.postsFolder).child(postID).setValue(["UserID": post.userID,
                                                                                                        "PostingUserName": post.name,
                                                                                                        "Description": post.description,
                                                                                                        "CreationTimestamp": post.creationTimestamp,
                                                                                                        "LikedBy": post.likedBy,
                                                                                                        "CommentsBy": post.commentsBy])
        {
            (error, ref) in
            if error == nil {
                successes[1] = true
            }
            postUploadingGroup.leave()
        }
        
        databaseReference.child(FirebaseAPIHandler.databaseFolders.usersFolder).child(post.userID).observeSingleEvent(of: .value)
        {
            (snapshot) in
            guard let informationDictionary = snapshot.value as? [String: Any] else {
                postUploadingGroup.leave()
                return
            }
            var postsArray = Array<String>()
            if let fetchedPosts = informationDictionary["Posts"] as? Array<String> {
                postsArray = fetchedPosts
            }
            postsArray.append(postID)
            self.databaseReference.child(FirebaseAPIHandler.databaseFolders.usersFolder).child(post.userID).updateChildValues(["Posts": postsArray])
            {
                (error, ref) in
                if error == nil {
                    successes[2] = true
                }
                postUploadingGroup.leave()
            }
        }
        
        postUploadingGroup.notify(queue: .global())
        {
            var failedAStep = false
            for i in 0..<successes.count {
                if successes[i] == false {
                    failedAStep = true
                }
            }
            // TODO: 
            // delete all references to this post
            // 1. delete image
            // 2. delete post
            // 3. update user's "Posts" Key:Value array to remove this postID
        }
        
    }
    
    func fetchPost(userID: String, postID: String, completion: @escaping (Post?) -> ())
    {
        var post: Post?
        
        // databaseReference.child(databaseFolders.postsFolder).child(postID).observeSingleEvent(of: .value)
        // {
        //      (snapshot) in
        //      guard let snapshot = snapshot else {
        //          completion(nil)
        //          return
        //      }
        //
    }
    
    // can return an empty array
    func fetchPostsByUser(userID: String, completion: @escaping (Array<Post>) -> ())
    {
        var posts = Array<Post>()
        
        // go to user
        // get list of posts
        //      databaseReference.child(databaseFolders.usersFolder).child(userID).child(
        //      var postIDs = [String]()
        // go to posts
        //      for postID in postIDs {
        //          dispatchGroup.enter()
        //          fetchPost(userID: userID, postID: postID){ (post) in ... dispatchGroup.leave() }
        //      {
        //      dispatchGroup.notify(queue: .main){ completion(posts) }
        // }
    }
    
    func fetchAllPosts(completion: @escaping (Array<UserPost>) -> ())
    {
        
    }
}
